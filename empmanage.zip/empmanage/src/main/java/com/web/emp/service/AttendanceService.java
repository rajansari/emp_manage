package com.web.emp.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.web.emp.repo.AttendanceRepo;

@Service
public class AttendanceService {

	@Autowired AttendanceRepo attendanceRepo;
	
	public Map<String, Object> getEmployeeAttendance() {
		return attendanceRepo.getEmployeeAttendance();
	}
}
