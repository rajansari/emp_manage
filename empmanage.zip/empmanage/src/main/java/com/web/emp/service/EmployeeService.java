package com.web.emp.service;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.web.emp.model.Employee;
import com.web.emp.repo.EmployeeRepo;

@Service
public class EmployeeService {
	
	@Autowired
	EmployeeRepo employeeRepo;
	
	public Employee addEmployee(Employee e) {
		return employeeRepo.save(e);
	}
	
	public Employee updateEmployee(Employee e) {
		return employeeRepo.update(e);
	}
	
	public Map<String, Object> deleteEmployee(int id) {
		return employeeRepo.delete(id);
	}
	
	public Employee getEmployeeById(int id) {
		return employeeRepo.get(id);
	}

}
