package com.web.emp.repo;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.web.emp.model.Employee;

@Repository
public class AttendanceRepo {
	
	public Map<String, Object> getEmployeeAttendance() {
		Map<String, Object> apiStatus = new HashMap<>();
		Date today = new Date();
		Calendar cal = Calendar.getInstance();
		cal.setTime(today);
	
		String monthName =  new SimpleDateFormat("MMM").format(cal.getTime());
		int days =  cal.getActualMaximum(Calendar.DAY_OF_MONTH);
		List<Employee> empList = new ArrayList<>();
		for(int i = 0; i <= days; i++) {
			empList.add(new Employee(1, "Rohin", "Josh", true));
		}
		
		if (!empList.isEmpty()) {
			apiStatus.put("MonthName", monthName);
			apiStatus.put("totolDays", days);
			apiStatus.put("result", empList);
			apiStatus.put("message", "Employee found for month ["+monthName+"]");
			apiStatus.put("status", true);
			
		} else {
			apiStatus.put("message", "Employee not found.");
			apiStatus.put("status", false);
		}
		
		return apiStatus;
	}
	

}
