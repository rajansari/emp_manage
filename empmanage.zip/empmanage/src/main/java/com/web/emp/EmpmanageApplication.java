package com.web.emp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmpmanageApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmpmanageApplication.class, args);
	}

}
