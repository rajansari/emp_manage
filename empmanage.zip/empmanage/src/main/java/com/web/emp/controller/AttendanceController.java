package com.web.emp.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.web.emp.model.User;
import com.web.emp.service.AttendanceService;

@RestController
@RequestMapping("/api")
public class AttendanceController {
	
	@Autowired AttendanceService attendanceService;
	
	@GetMapping("/employee/attendance")
	public ResponseEntity<Map<String, Object>> getEmployeeAttendance(){
		User manager = User.getManagerUser();
	
		Map<String, Object> apiStatus = new HashMap<>();
		if(manager.getRole().equalsIgnoreCase("Manager")) {
			apiStatus = attendanceService.getEmployeeAttendance();
		}
		
		if((boolean) apiStatus.get("status") == true) 
			return new ResponseEntity<Map<String, Object>>(apiStatus, HttpStatus.OK);
		else
			return new ResponseEntity<Map<String, Object>>(apiStatus, HttpStatus.NOT_FOUND);
	}

}
