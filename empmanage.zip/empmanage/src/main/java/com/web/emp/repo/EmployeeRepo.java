package com.web.emp.repo;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.web.emp.model.Employee;

@Repository
public class EmployeeRepo {
	
	public Employee save(Employee e) {
		
		Employee emp = new Employee(e.getEmployeeID(), e.getFirstName(), e.getLastName());
		System.out.print(emp.toString());
		return emp;
	}
	
	public Employee update(Employee e) {
		Employee emp = null; 
		if (e.getEmployeeID() == 12) {
			emp = Employee.createDemoEmployeeByID(12);
			if (!emp.getFirstName().equals(e.getFirstName())) {
				emp.setFirstName(e.getFirstName());
			}
			if (!emp.getLastName().equals(e.getLastName())) {
				emp.setLastName(e.getLastName());
			}
		}
		System.out.print(emp.toString());
		return emp;
	}
	
	public Map<String, Object> delete(int id) {
		Map<String, Object> apiStatus = new HashMap<String, Object>(); 
		if (id > 0) { 
			apiStatus.put("message", "Employee has been deleted by id ["+id+"]");
			apiStatus.put("status", true);
		}
		else {
			apiStatus.put("message", "Employee not found by id ["+id+"]");
			apiStatus.put("status", false);
		}
		return apiStatus;
	}
	
	public Employee get(int id) {
		
		Employee emp = null;
		if(id == 11) 
			emp = new Employee(11, "firstTestName", "lastTestName");

		System.out.print(emp.toString());
		
		return emp;
	}

}
