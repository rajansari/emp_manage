package com.web.emp.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.web.emp.model.Employee;
import com.web.emp.model.User;
import com.web.emp.service.EmployeeService;

@RestController
@RequestMapping("/api")
public class EmployeeController {
	
	@Autowired
	private EmployeeService employeeService;
	
	@PostMapping("/employee")
	public ResponseEntity<Employee> addEmployee(@RequestBody Employee employee){
		User manager = User.getManagerUser();
		Employee emp = null;
		if(manager.getRole().equalsIgnoreCase("Manager")) {
			emp = employeeService.addEmployee(employee);
		}
		
		if(emp != null)
			return new ResponseEntity<Employee>(emp, HttpStatus.OK);
		else
			return new ResponseEntity<Employee>(emp, HttpStatus.NOT_FOUND);
	}
	
	@PutMapping("/employee")
	public ResponseEntity<Employee> updateEmployee(@RequestBody Employee employee){
		User manager = User.getManagerUser();
		Employee emp = null;
		if(manager.getRole().equalsIgnoreCase("Manager")) {
			emp = employeeService.updateEmployee(employee);
		}
		
		if(emp != null)
			return new ResponseEntity<Employee>(emp, HttpStatus.OK);
		else
			return new ResponseEntity<Employee>(emp, HttpStatus.NOT_FOUND);
	}
	
	@DeleteMapping("/employee/{id}")
	public ResponseEntity<Map<String, Object>> deleteEmployee(@PathVariable int id){
		User manager = User.getManagerUser();
		Map<String, Object> apiStatus = new HashMap<>();
		if(manager.getRole().equalsIgnoreCase("Manager")) {
			apiStatus = employeeService.deleteEmployee(id);
		}
		
		if((boolean) apiStatus.get("status") == true) 
			return new ResponseEntity<Map<String, Object>>(apiStatus, HttpStatus.OK);
		else
			return new ResponseEntity<Map<String, Object>>(apiStatus, HttpStatus.NOT_FOUND);
	}
	
	@GetMapping("/employee/{id}")
	public ResponseEntity<Employee> getEmployeeById(@PathVariable int id){
		User manager = User.getManagerUser();
		Employee emp = null;
		if(manager.getRole().equalsIgnoreCase("Manager")) {
			emp = employeeService.getEmployeeById(id);
		}
		
		if(emp != null)
			return new ResponseEntity<Employee>(emp, HttpStatus.OK);
		else
			return new ResponseEntity<Employee>(emp, HttpStatus.NOT_FOUND);
	}

}
